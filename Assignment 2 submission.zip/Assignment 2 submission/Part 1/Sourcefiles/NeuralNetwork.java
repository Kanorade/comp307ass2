package NeuralNetwork;

import java.util.Arrays;

public class NeuralNetwork {
    public final double[][] hidden_layer_weights;
    public final double[][] output_layer_weights;
    public final double[] biases;
    private final int num_inputs;
    private final int num_hidden;
    private final int num_outputs;
    private final double learning_rate;

    public NeuralNetwork(int num_inputs, int num_hidden, int num_outputs, double[][] initial_hidden_layer_weights,
                         double[][] initial_output_layer_weights, double learning_rate,
                         double[] biases) {
        //Initialise the network
        this.num_inputs = num_inputs;
        this.num_hidden = num_hidden;
        this.num_outputs = num_outputs;

        this.hidden_layer_weights = initial_hidden_layer_weights;
        this.output_layer_weights = initial_output_layer_weights;
        this.biases = biases;

        this.learning_rate = learning_rate;

    }


    //Calculate neuron activation for an input
    public double sigmoid(double input) {
        return 1 / (1 + Math.exp(-input));
    }

    //Feed forward pass input to a network output
    public double[][] forward_pass(double[] inputs) {
        double[] hidden_layer_outputs = new double[num_hidden];
//        System.out.println("\nCalculating hidden weights:");
        for (int i = 0; i < num_hidden; i++) {
            double weighted_sum = 0;
//            System.out.print("Sum for hidden node " + (i+1) + ":");
            for (int j = 0; j < num_inputs; j++) {
                weighted_sum += hidden_layer_weights[j][i] *  inputs[j];
//                System.out.print(" + (" + hidden_layer_weights[j][i] + "*" + inputs[j] + ")");
            }
//            System.out.println(" = " + weighted_sum);

            // add bias
            weighted_sum += biases[i];

            double output = sigmoid(weighted_sum);
//            System.out.println("output: sigmoid(" + weighted_sum + ") = " + output + "\n");
            hidden_layer_outputs[i] = output;
        }

        double[] output_layer_outputs = new double[num_outputs];
//        System.out.println("\nCalculating output weights:");
        for (int i = 0; i < num_outputs; i++) {
            double weighted_sum = 0;
//            System.out.print("Sum for output node " + (i+1) + ":");
            for (int j = 0; j < num_hidden; j++) {
                weighted_sum += output_layer_weights[j][i] * hidden_layer_outputs[j];
//                System.out.print(" + (" + output_layer_weights[j][i] + "*" + hidden_layer_outputs[j] + ")");
            }
//            System.out.println(" = " + weighted_sum);

            // Add bias
            weighted_sum += biases[i + num_hidden];

            double output = sigmoid(weighted_sum);
//            System.out.println("output: sigmoid(" + weighted_sum + ") = " + output + "\n");
            output_layer_outputs[i] = output;
        }
        return new double[][]{hidden_layer_outputs, output_layer_outputs};
    }

    public double[][][] backward_propagate_error(double[] inputs, double[] hidden_layer_outputs,
                                                 double[] output_layer_outputs, int desired_outputs) {

        double[] output_layer_betas = new double[num_outputs];
        for (int i = 0; i < num_outputs; i++) {
            int d = (i == desired_outputs) ? 1 : 0;
            output_layer_betas[i] = d - output_layer_outputs[i];
        }
        //System.out.println("OL betas: " + Arrays.toString(output_layer_betas));

        double[] hidden_layer_betas = new double[num_hidden];
        for (int i = 0; i < num_hidden; i++) {
            double beta_sum = 0;
            double[] output_weights_for_hidden_Node = output_layer_weights[i];
            for (int j = 0; j < num_outputs; j++) {
            beta_sum += output_weights_for_hidden_Node[j] *
                    output_layer_outputs[j] *
                    (1 - output_layer_outputs[j]) *
                    output_layer_betas[j];
            }
            hidden_layer_betas[i] = beta_sum;
        }
        //System.out.println("HL betas: " + Arrays.toString(hidden_layer_betas));

        // This is a HxO array (H hidden nodes, O outputs)
        double[][] delta_output_layer_weights = new double[num_hidden][num_outputs];
        for (int h = 0; h < num_hidden; h++) {
            for (int o = 0; o < num_outputs; o++) {
                delta_output_layer_weights[h][o] =
                        learning_rate * hidden_layer_outputs[h] * output_layer_outputs[o] *
                                (1 - output_layer_outputs[o]) * output_layer_betas[o];
            }
        }
        // This is a IxH array (I inputs, H hidden nodes)
        double[][] delta_hidden_layer_weights = new double[num_inputs][num_hidden];
        for (int i = 0; i < num_inputs; i++) {
            for (int h = 0; h < num_hidden; h++) {
                delta_hidden_layer_weights[i][h] =
                        learning_rate * inputs[i] * hidden_layer_outputs[h] *
                                (1 - hidden_layer_outputs[h]) * hidden_layer_betas[h];
            }
        }

        // Calculate change in bias weights, is a 2d for compatibility reasons
        double [][] delta_biases = new double[1][num_hidden+num_outputs];
        for (int i = 0; i < num_hidden; i++) {
            delta_biases[0][i] = learning_rate*hidden_layer_outputs[i]*
                    (1-hidden_layer_outputs[i])*hidden_layer_betas[i];
        }

        for (int i = 0; i < num_outputs; i++) {
            delta_biases[0][num_hidden+i] = learning_rate*output_layer_outputs[i]*
                    (1-output_layer_outputs[i])*output_layer_betas[i];
        }

        // Return the weights we calculated, so they can be used to update all the weights.
        return new double[][][]{delta_output_layer_weights, delta_hidden_layer_weights, delta_biases};
    }

    public void update_weights(double[][] delta_output_layer_weights, double[][] delta_hidden_layer_weights,
                               double[][] delta_biases) {
        //System.out.println("delta_output_layer_weights: \n" + Arrays.deepToString(delta_output_layer_weights));
        //System.out.println("delta_hidden_layer_weights: \n" + Arrays.deepToString(delta_hidden_layer_weights));
        // Update hidden layer weights
        for (int i = 0; i < num_inputs; i++) {
            for (int h = 0; h < num_hidden; h++) {
                hidden_layer_weights[i][h] += delta_hidden_layer_weights[i][h];
            }
        }
        // Update output layer weights
        for (int h = 0; h < num_hidden; h++) {
            for (int o = 0; o < num_outputs; o++) {
                output_layer_weights[h][o] += delta_output_layer_weights[h][o];
            }
        }

        // Update bias weights
        for (int i = 0; i < (num_hidden + num_outputs); i++) {
            biases[i] += delta_biases[0][i];
        }
    }

    public void train(double[][] instances, int[] desired_outputs, int epochs) {
        for (int epoch = 0; epoch < epochs; epoch++) {
            System.out.println("\nepoch = " + epoch);
            int[] predictions = new int[instances.length];
            for (int i = 0; i < instances.length; i++) {
                double[] instance = instances[i];
                double[][] outputs = forward_pass(instance);
                double[][][] delta_weights = backward_propagate_error(instance, outputs[0], outputs[1], desired_outputs[i]);
                int predicted_class = predictedClassIntFromOutputs(outputs);
                predictions[i] = predicted_class;

                //We use online learning, i.e. update the weights after every instance.
                update_weights(delta_weights[0], delta_weights[1], delta_weights[2]);
            }

            // Print new weights
            System.out.println("Hidden layer weights \n" + Arrays.deepToString(hidden_layer_weights));
            System.out.println("Output layer weights  \n" + Arrays.deepToString(output_layer_weights));

            int successCount = 0;
            assert(instances.length == desired_outputs.length);
            for (int i = 0; i < predictions.length; i++) {
                if (predictions[i] == desired_outputs[i]) {
                    successCount++;
                }
            }
            double acc = (double)successCount/predictions.length;
            System.out.println("acc = " + acc);
        }
    }

    public int[] predict(double[][] instances) {
        int[] predictions = new int[instances.length];
        for (int i = 0; i < instances.length; i++) {
            double[] instance = instances[i];
            double[][] outputs = forward_pass(instance);

            int predicted_class = predictedClassIntFromOutputs(outputs);

            predictions[i] = predicted_class;
        }
        return predictions;
    }
    public int predictedClassIntFromOutputs(double[][] outputs) {
        int predicted_class = 0;  // let's assume class 0 is best and change it if wrong
        for (int j = 1; j < num_outputs; j++) { // Start j=1, since we're assuming class 0 is best
            if (outputs[1][j] > outputs[1][predicted_class]) {
                predicted_class = j;
            }
        }
        return predicted_class;
    }

}
