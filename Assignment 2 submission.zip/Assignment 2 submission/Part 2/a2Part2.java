package SymbolicRegression;

import org.jgap.Configuration;
import org.jgap.InvalidConfigurationException;
import org.jgap.Population;
import org.jgap.RandomGenerator;
import org.jgap.audit.EvolutionMonitor;
import org.jgap.audit.IEvolutionMonitor;
import org.jgap.eval.PopulationHistoryIndexed;
import org.jgap.gp.CommandGene;
import org.jgap.gp.GPFitnessFunction;
import org.jgap.gp.GPProblem;
import org.jgap.gp.IGPProgram;
import org.jgap.gp.function.*;
import org.jgap.gp.impl.DeltaGPFitnessEvaluator;
import org.jgap.gp.impl.GPConfiguration;
import org.jgap.gp.impl.GPGenotype;
import org.jgap.gp.terminal.Terminal;
import org.jgap.gp.terminal.Variable;
import org.jgap.impl.CauchyRandomGenerator;
import org.jgap.impl.RandomGeneratorForTesting;
import org.jgap.impl.SeededRandomGenerator;

import java.util.List;

public class a2Part2 extends GPProblem {
    private static final double[] X_INPUTS = {-2.00 , -1.75, -1.50, -1.25, -1.00, -0.75, -0.50, -0.25,
            0.00, 0.25, 0.50, 0.75, 1.00, 1.25, 1.50, 1.75, 2.00, 2.25, 2.50, 2.75};
    private static final double[] Y_OUTPUTS = {37.00000, 24.16016, 15.06250, 8.91016, 5.00000,
            2.72266, 1.56250, 1.09766, 1.00000, 1.03516, 1.06250, 1.03516, 1.00000,
            1.09766, 1.56250, 2.72266, 5.00000, 8.91016, 15.06250, 24.16016};
    private final Variable xVar;
    private final static int MAX_DEPTH = 17;
    private final static int POPULATION = 1000;
    private static final int GENERATIONS = 200;
    private static final float REPRODUCTION_RATE = 0.05f;
    private static final float CROSSOVER_RATE = 0.9f;
    private static final float MUTATION_RATE = 0.1f;
    private static final long RANDOM_SEED = 0;
    private static final double SUCCESSFUL_FITNESS_VALUE = 0.01; // Stop evolving if fitness is below this value
    public a2Part2() throws InvalidConfigurationException {
        super (new GPConfiguration());
            GPConfiguration config = getGPConfiguration();

            xVar = Variable.create(config, "X", CommandGene.DoubleClass);

            // Set Fitness Evaluator to take inputs as delta values
            // ie. error values, the lower the number, the fitter it is
            config.setGPFitnessEvaluator(new DeltaGPFitnessEvaluator());
            config.setMaxInitDepth(MAX_DEPTH);
            config.setPopulationSize(POPULATION);
            //config.setMaxCrossoverDepth(8); //TODO! I don't know what this is
            config.setFitnessFunction(new SymRegFitnessFunction(X_INPUTS, Y_OUTPUTS, xVar));
            config.setStrictProgramCreation(true);
            config.setRandomGenerator(new SeededRandomGenerator(RANDOM_SEED));
            config.setMutationProb(MUTATION_RATE);
            config.setCrossoverProb(CROSSOVER_RATE);
            config.setReproductionProb(REPRODUCTION_RATE);
            config.setMonitor(new FitnessMonitor());
    }
    static class FitnessMonitor implements IEvolutionMonitor {
        @Override
        public void start(Configuration a_config) {

        }

        @Override
        public boolean nextCycle(Population a_pop, List<String> a_messages) {
            double fitness = a_pop.determineFittestChromosome().getFitnessValue();
            // Keep running if fitness is higher than success criteria
            return fitness > SUCCESSFUL_FITNESS_VALUE;
        }

        @Override
        public void event(String a_monitorEvent, int a_evolutionNo, Object[] a_information) {

        }

        @Override
        public PopulationHistoryIndexed getPopulations() {
            return null;
        }
    }

    @Override
    public GPGenotype create() throws InvalidConfigurationException {
        GPConfiguration config = getGPConfiguration();

        // The return type of the GP program.
        Class[] types = { CommandGene.DoubleClass };

        // Arguments of result-producing chromosome: none
        Class[][] argTypes = {{}};  // Following example code here

        // Define functions and terminals for the tree
        // Note: Lecture notes say use protected divide function,
        // but couldn't find it in this library
        CommandGene[][] nodeSets = {{xVar,
                new Add(config, CommandGene.DoubleClass),
                new Subtract(config, CommandGene.DoubleClass),
                new Multiply(config, CommandGene.DoubleClass),
                new Divide(config, CommandGene.DoubleClass),
                new Terminal(config, CommandGene.DoubleClass, 0.0, 10.0, false),

                new Pow(config, CommandGene.IntegerClass)
        }};

        GPGenotype result = GPGenotype.randomInitialGenotype(config, types, argTypes,
                nodeSets, 20, false);
        return result;
    }
    static class SymRegFitnessFunction extends GPFitnessFunction {
        private final double[] inputs;
        private final double[] expected_outputs;
        private final Variable xVar;

        private static final Object[] NO_ARGS = new Object[0];
        public SymRegFitnessFunction(double[] inputs, double[] expected_outputs, Variable x) {
            this.inputs = inputs;
            this.expected_outputs = expected_outputs;
            this.xVar = x;
        }

        @Override
        protected double evaluate(IGPProgram a_subject) {
            double result = 0;
            for (int i = 0; i < inputs.length; i++) {
                xVar.set(inputs[i]);
                // Execute the genetically engineered algorithm
                double output = a_subject.execute_double(0, NO_ARGS);
                result += Math.abs(output - expected_outputs[i]);
            }
            return result; // Total of all errors, closer to zero, the better
        }
    }
    public static void main(String[] args) throws InvalidConfigurationException {
        GPProblem problem = new a2Part2();

        GPGenotype gp = problem.create();
        gp.setVerboseOutput(true);
        gp.evolve(GENERATIONS);

        gp.outputSolution(gp.getAllTimeBest());
    }
}

