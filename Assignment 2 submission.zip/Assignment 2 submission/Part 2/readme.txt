To run the file, execute;

     java -jar a2Part2.jar

Due to not understanding how log4j works, expect a FileNotFoundException. The code should still work.
Also expect a log file to appear in the same directory as this jar file.